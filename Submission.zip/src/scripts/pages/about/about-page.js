export default class AboutPage {
  async render() {
    return `
      <section class="container">
        <h1 style="color: white; margin: auto;">email: fauzanilham630@gmail.com</h1>
      </section>
    `;
  }

  async afterRender() {
    
  }
}
